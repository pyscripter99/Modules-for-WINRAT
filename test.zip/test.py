def run():
    print("My test module!")